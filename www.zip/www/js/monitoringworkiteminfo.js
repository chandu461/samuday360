var surveycode="";

screenheight=parseInt(screen.height)-120
$("#wokitemview").height(screenheight)

function populateWorkItemDetails(results)
{
	Iteminfo=results.rows[0];
	$("#workitemnameh").html(Iteminfo.workitemname);
	$("#WorkItemDescspan").html(function(){if(Iteminfo.workitemdesc!=null && Iteminfo.workitemdesc!="null"){return Iteminfo.workitemdesc;}else{return ""}});
	$("#WorkItemTypespan").html(Iteminfo.workitemtype);
	$("#PlanStartDatespan").html(Iteminfo.planstartdate);
	$("#PlanEndDatespan").html(Iteminfo.planenddate);
	$("#PrimaryOwnerspan").html(Iteminfo.primaryowner);
	$("#Targetspan").html(Iteminfo.target);
	$("#CreatedByspan").html(Iteminfo.createdby);
	$("#frequencymodal").html(Iteminfo.frequncy) // Only for Mointoring Survey
}


function populateSurveyDetails(results)
{

	Iteminfo=results.rows[0];
	surveycode=Iteminfo.surveycode
	$("#surveyname").html(Iteminfo.surveyname)
	$("#surveynamemodal").html(Iteminfo.surveyname)
	$("#surveydescmodal").html(Iteminfo.surveydesc)
	$("#sectorcodemodal").html(Iteminfo.sectorcode)
	$("#programcodemodal").html(Iteminfo.programcode)
	$("#intervensioncodemodal").html(Iteminfo.interventioncode)
	$("#createdbymodal").html(Iteminfo.createdby)
	$("#createdonmodal").html(Iteminfo.createdon)
	$("#typemodal").html(function (){if(Iteminfo.type=="MS"){return "Monitoring Survey"}else if(Iteminfo.type=="BS"){return "Baseline Survey"}})
	//$("#frequencymodal").html(Iteminfo.frequency) // Only for Mointoring Survey
	$("#startdatemodal").html(Iteminfo.startdate)
	$("#enddatemodal").html(Iteminfo.enddate)
	filterLoadBlocks();
}

function populateLocaitionDetails(results)
{
	Iteminfo=results.rows;
	surveylocation=[];
	for(loop=0; loop<Iteminfo.length; loop++)
	{surveylocation.push(Iteminfo[loop].locationname);}
	$("#surveylocations").html(surveylocation.toString());
}

$("#calendarbtn").on("click", function(){
	$("#event-cal-container").toggle();
})

function downloaddata()
{
	SpinnerDialog.show("Samuday 360", "Loading...", true);
	surveyworkitemmappingcode=CryptoJS.AES.decrypt(localStorage.surveyworkitemmappingcode, "Samuday360").toString(CryptoJS.enc.Utf8).slice(1,-1);
	survey=CryptoJS.AES.decrypt(localStorage.survey, "Samuday360").toString(CryptoJS.enc.Utf8).slice(1,-1);
	workitemcode=CryptoJS.AES.decrypt(localStorage.workitem, "Samuday360").toString(CryptoJS.enc.Utf8).slice(1,-1);

	$.ajax({
		url:localStorage.service+'downloadbeneficiary',
		type:"GET",
		//dataType:"json",
		//jsonp:"callback",
		async:true,
		data:{workitemcode:workitemcode, surveyworkitemmappingcode: surveyworkitemmappingcode, type:"MS", survey:survey},
		//ContentType:"application/json",
		success: function(response, message, status)
		{
			loadbendata=response;
			//console.log(response);
			insertorupdatebendata();
		},
		error: function(err)
		{
			//console.log(err);
			SpinnerDialog.hide();
			navigator.notification.alert("Please try again", function(){}, 'Samuday 360','Done');
			// $("#sheduleing").modal("hide");
		}
	});
	
	//$("#downloadatamodal").modal("show");
	//loadlocations();
}

function downloaddatacheck()
{
	alert($("#block").val());
	alert($("#filtergp").val());
	alert($("#filtervillage").val());
}