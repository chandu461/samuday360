
// To Store User Name
localStorage.usercode="user";

// To Store Password
localStorage.securityword="user";

// To Store 4 - Digit PIN
localStorage.securitycode;

// TEMP To Store Mobile UUID
localStorage.uuid;

// TEMP To Store Email
localStorage.email="user@hcl.com"

// TEMP To Store Mobile Number
localStorage.mobile="9999999999"


// TEMP To Store Employee ID
localStorage.employeeid="00001"


